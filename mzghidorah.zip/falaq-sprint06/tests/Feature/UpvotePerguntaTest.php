<?php

namespace Tests\Feature;

use App\Models\Evento;
use App\Models\Pergunta;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UpvotePerguntaTest extends TestCase
{
    use RefreshDatabase;

    private function criarPergunta(string $texto = 'Pergunta de teste com texto longo'): Pergunta
    {
        $dono = User::factory()->create();
        $evento = Evento::create(['titulo' => 'Evento', 'user_id' => $dono->id]);

        return Pergunta::create([
            'evento_id' => $evento->id,
            'user_id'   => $dono->id,
            'texto'     => $texto,
            'status'    => 'pendente',
        ]);
    }

    public function test_anonimo_nao_pode_votar(): void
    {
        $pergunta = $this->criarPergunta();

        $this->post(route('perguntas.votar', $pergunta))
            ->assertRedirect();

        $this->assertDatabaseCount('pergunta_user', 0);
    }

    public function test_usuario_logado_vota_e_registro_e_criado(): void
    {
        $user = User::factory()->create();
        $pergunta = $this->criarPergunta();

        $this->actingAs($user)
            ->post(route('perguntas.votar', $pergunta))
            ->assertRedirect();

        $this->assertDatabaseHas('pergunta_user', [
            'pergunta_id' => $pergunta->id,
            'user_id'     => $user->id,
        ]);
    }

    public function test_segundo_clique_remove_o_voto(): void
    {
        $user = User::factory()->create();
        $pergunta = $this->criarPergunta();

        $this->actingAs($user)->post(route('perguntas.votar', $pergunta));
        $this->actingAs($user)->post(route('perguntas.votar', $pergunta));

        $this->assertDatabaseCount('pergunta_user', 0);
    }

    public function test_banco_impede_voto_duplicado(): void
    {
        $user = User::factory()->create();
        $pergunta = $this->criarPergunta();

        $pergunta->votos()->attach($user->id);

        $this->expectException(QueryException::class);
        $pergunta->votos()->attach($user->id);
    }

    public function test_relacionamentos_funcionam_nos_dois_lados(): void
    {
        $user = User::factory()->create();
        $pergunta = $this->criarPergunta();

        $pergunta->votos()->attach($user->id);

        $this->assertTrue($pergunta->votos->contains($user));
        $this->assertTrue($user->perguntasVotadas->contains($pergunta));
    }

    public function test_perguntas_sao_ordenadas_por_votos(): void
    {
        $dono = User::factory()->create();
        $evento = Evento::create(['titulo' => 'Evento', 'user_id' => $dono->id]);

        // A mais votada é a mais ANTIGA: só o ranking por votos a coloca no topo.
        $popular = Pergunta::create(['evento_id' => $evento->id, 'user_id' => $dono->id, 'texto' => 'PERGUNTA_POPULAR', 'status' => 'pendente', 'created_at' => now()->subDay()]);
        $comum   = Pergunta::create(['evento_id' => $evento->id, 'user_id' => $dono->id, 'texto' => 'PERGUNTA_COMUM', 'status' => 'pendente']);

        $popular->votos()->attach(User::factory()->count(3)->create()->pluck('id'));
        $comum->votos()->attach(User::factory()->create()->id);

        $this->withoutVite()
            ->get(route('eventos.show', $evento->id))
            ->assertOk()
            ->assertSeeInOrder(['PERGUNTA_POPULAR', 'PERGUNTA_COMUM']);
    }
}
